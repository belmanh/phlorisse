/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import models.User;
import services.SystemService;

/**
 *
 * @author hp
 */
public class C_Login implements Initializable {
    
   
    @FXML
    private TextField txtLogin;
    @FXML
    private PasswordField txtPwd;
    @FXML
    private Button btnConnexion;
    @FXML
    private Button btnAnnuler;
    @FXML
    private Text lblError;
    
    private User u;
    private static C_Login  instance;

    public static C_Login getInstance() {
        return instance;
    }
   
    public User getUser() {
        return u;
    }
    
    SystemService service;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        service=new SystemService();
        instance=this;
        
    }    

    @FXML
    private void handleConnexion(ActionEvent event) throws IOException {
        String login=txtLogin.getText();
        String pwd =txtPwd.getText();
         u =service.seConnecter(login, pwd);
         if(u==null ){
             lblError.setText("Login ou Mot de passe Incorrect");
             lblError.setVisible(true);
         }else{
             Stage stage=new Stage();
             if(u.getEtat().compareTo("Actif")==0){
                  lblError.getScene().getWindow().hide();
                   AnchorPane root = FXMLLoader.load(getClass().getResource("/views/V_Dashboard.fxml"));
                      Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                  
             }else{
             lblError.setText("User bloqué"); 
              lblError.setVisible(true);
         }
         }
             
        
    }
    
}
