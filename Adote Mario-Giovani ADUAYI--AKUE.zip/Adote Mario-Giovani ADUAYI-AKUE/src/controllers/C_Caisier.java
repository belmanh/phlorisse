/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import models.Profil;
import models.User;
import services.SystemService;

/**
 * FXML Controller class
 *
 * @author user
 */
public class C_Caisier implements Initializable {

    @FXML
    private TextField txtNom;
    @FXML
    private TextField txtPrenom;
    @FXML
    private TextField txtLogin;
    @FXML
    private PasswordField txtPwd;
    @FXML
    private ComboBox<String> cboEtat;
    @FXML
    private Button btnAnnuler;
    @FXML
    private Button btnEnregistrer;
    @FXML
    private Button btnModifier;
    @FXML
    private TableView<User> tblvCaissier;
    @FXML
    private TableColumn<User, String> tblcNom;
    @FXML
    private TableColumn<User, String> tblcPrenom;
    @FXML
    private TableColumn<User, String> tblcProfil;
    @FXML
    private TableColumn<User,String> tblcEtat;
    SystemService service;
    ObservableList<User> obvcaissiers;
    User caissierselect;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       cboEtat.getItems().add("Actif");
       cboEtat.getItems().add("Inactif");
       service=new SystemService();
       List<User> caissiers=service.listerCaissier();
        obvcaissiers=FXCollections.observableArrayList(caissiers);
       tblcNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
       tblcPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
       tblcProfil.setCellValueFactory(new PropertyValueFactory<>("profil"));
       tblcEtat.setCellValueFactory(new PropertyValueFactory<>("etat"));
       tblvCaissier.setItems(obvcaissiers);
    }    

    @FXML
    private void handleSaveCaissier(ActionEvent event) {
        User u=new User(txtNom.getText(), txtPrenom.getText(), txtLogin.getText(), txtPwd.getText());
             u.setEtat(cboEtat.getSelectionModel().getSelectedItem());
        if(service.creerCaissier(u)){
           Alert alert=new Alert(Alert.AlertType.INFORMATION);
           alert.setContentText("Caissier Enregisté avec succees");
           alert.showAndWait();
           obvcaissiers.add(u);
       }else{
            Alert alert=new Alert(Alert.AlertType.ERROR);
           alert.setContentText("Erreur");
       }
       txtNom.clear();
    }

    @FXML
    private void handleChangeEtat(ActionEvent event) {
       service.bloquerUser(caissierselect.getId(),
               cboEtat.getSelectionModel().getSelectedItem());
   
    }

    @FXML
    private void handleEditCaissier(MouseEvent event) {
        caissierselect= tblvCaissier.getSelectionModel().getSelectedItem();
        txtNom.setText(caissierselect.getNom());
        txtPrenom.setText(caissierselect.getPrenom());
    }
    
}
