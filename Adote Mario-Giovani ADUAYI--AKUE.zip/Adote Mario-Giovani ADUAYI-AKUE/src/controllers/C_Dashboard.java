/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import models.User;

/**
 * FXML Controller class
 *
 * @author user
 */
public class C_Dashboard implements Initializable {

    @FXML
    private AnchorPane lblDepot;
      private User userConnect;
    @FXML
    private Text lblNom;
    @FXML
    private Text lblPrenom;
    @FXML
    private Text lbllProfil;
    @FXML
    private Label mnuDepot;
    @FXML
    private Label mnuCaissier;
    @FXML
    private AnchorPane annchorContent;

    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        userConnect=C_Login.getInstance().getUser();
        lblNom.setText("Nom :"+userConnect.getNom().substring(0, 1).toUpperCase()+userConnect.getNom().substring(1));
        lblPrenom.setText("Prenom :"+userConnect.getPrenom().substring(0, 1).toUpperCase());
        lbllProfil.setText("Profil"+userConnect.getProfil().getLibelle());
          if(userConnect.getProfil().getLibelle().compareTo("Caissier")==0){
              mnuCaissier.setDisable(true);
          }
    }    

    @FXML
    private void handleDepot(MouseEvent event) {
        System.out.println("Depot");
    }

    @FXML
    private void handleShowCaissier(MouseEvent event) throws IOException {
        annchorContent.getChildren().clear();
        AnchorPane root = FXMLLoader.load(getClass().getResource("/views/V_Caisier.fxml"));
        annchorContent.getChildren().add((Node)root);
    }
    
}
